const mysql = require('mysql')
const path = require('path') 

var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password",
    database: "DP",
    port: "3306"
})

connection.connect((err)=>{
    if(err){
        throw err
    } else{
        console.log("connected");
    }
})

exports.view = (req, res) => {
    // User the connection
    connection.query('SELECT * FROM FormofPatient', (err, rows) => {
      // When done with the connection, release it
      if (!err) {
        res.sendFile(path.join(__dirname+"../../../public/yo.html"))
      } else {
        console.log(err);
      }
      console.log('The data from user table: \n', rows);
    });
  }

exports.add = (req, res) => {
    // User the connection
    connection.query('Insert into FormofPatient (PatientID, FirstName, LastName , Age ,Address1 ,Address2, City ,Governorate ,Zip_Code ,Phone_Number ,Relationship ,Appointment ,Q1   ,Q2  ,Q3  ,Q4   ,Q5  ,Q6 ,Q7 ,Q8 ,Q9) Values ("' + req.body.PatientID + '", "' + req.body.Firstname + '", "' + req.body.Lastname + '", "' + req.body.Age + '" ,"' + req.body.Address + '","' + req.body.Address2 +'", "' + req.body.City + '","' + req.body.Governorate + '","' + req.body.Zip + '","' + req.body.Phonenumber + '","' + req.body.Martialstatus + '","' + req.body.Areyoucurrentlyonanybirthcontrolplan + '","' + req.body.Doyouhaveinfertilityissues + '","' + req.body.Haveyoudoneanytumourmarkerbloodtestsbefore + '","' + req.body.Haveyoufeltlumpsinyourbreastswhenselfexamined + '","' + req.body.Doyousufferfromirritationrednessflakinessofskininthebreastornipplearea + '","' + req.body.Doyousufferfromthechangeofthebreastsizeorshape + '","' + req.body.Haveyourmothergrandmotherhadbreastcancer + '","' + req.body.Ifyouhaveprefereddateforyourappointmentpleasewriteit +  '") ;', (err, rows) => {
      // When done with the connection, release it
      if (!err) {
        res.sendFile(path.join(__dirname+"../../../public/yo.html"))
      } else {
        console.log(err);
      }
      console.log('The data from user table: \n', rows);
    });
}

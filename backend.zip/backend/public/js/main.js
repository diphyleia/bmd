const FormofPatient = document.querySelector('#Submit');
const PatientID = document.querySelector("#PatientID");
const FirstName = document.querySelector("#Firstname");
const LastName = document.querySelector("#Lastname");
const Age = document.querySelector("#Age");
const Address1 = document.querySelector("#Address");
const Address2 = document.querySelector("#Address2");
const City = document.querySelector("#City");
const Governorate = document.querySelector("#Governorate");
const Zip_Code = document.querySelector("#Zip");
const Phone_Number = document.querySelector("#Phonenumber");
const Relationship = document.querySelector("#Martialstatus");
const Q1 = document.querySelector("#Areyoucurrentlyonanybirthcontrolplan");
const Q2 = document.querySelector("#Doyouhaveinfertilityissues");
const Q3 = document.querySelector("#Haveyoudoneanytumourmarkerbloodtestsbefore");
const Q4 = document.querySelector("#Haveyoufeltlumpsinyourbreastswhenselfexamined");
const Q5 = document.querySelector("#Doyousufferfromirritationrednessflakinessofskininthebreastornipplearea");
const Q6 = document.querySelector("#Doyousufferfromthechangeofthebreastsizeorshape");
const Q7 = document.querySelector("#Haveyourmothergrandmotherhadbreastcancer");
const Q8 = document.querySelector("#IfyouhaveanyChronicdiseaseshistorypleasestatethemdown");



submitForm.addEventListener('click', (e) => {
    e.preventDefault()

    const report = {
        Uname: Uname.value,
        mail: mail.value,
        job: job.value,
        age: age.value,
        number: number.value
    }

    console.log(report);

    fetch('/', {
        method: 'post',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(report)
      }).then(res=>res.json())
        .then(res => console.log(res));

    PatientID.value = ""
    FirstName.value = ""
    LastName.value = ""
    Age.value = ""
    Address1.value = ""
    Address2.value = ""
    City.value = ""
    Governorate.value = ""
    Zip_Code.value = ""
    Phone_Number.value = ""
    Relationship.value = ""
    Q1.value = ""
    Q2.value = ""
    Q3.value = ""
    Q4.value = ""
    Q5.value = ""
    Q6.value = ""
    Q7.value = ""
    Q8.value = ""
    
});
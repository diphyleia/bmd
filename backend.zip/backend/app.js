const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

require('dotenv').config();

const app = express();
const port = 5000;


app.use(express.urlencoded({extended: true}));


app.use(express.json());


app.use(express.static('public'));

 

const routes = require('./server/routes/user');
app.use('/', routes);

app.listen(port, () => console.log(`Listening on port ${port}`));